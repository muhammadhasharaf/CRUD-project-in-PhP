<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Insert extends CI_Controller {
// For data insertion	
public function index(){
$this->form_validation->set_rules('firstname',' Name','required|alpha');	
$this->form_validation->set_rules('emailid','Email id','required|valid_email');
$this->form_validation->set_rules('contactno','Mobile No','required|numeric|exact_length[10]');
$this->form_validation->set_rules('dob','Date Of Birth','required');	
$this->form_validation->set_rules('pincode','Pincode','required');	

if($this->form_validation->run()){
$fname=$this->input->post('firstname');
$email=$this->input->post('emailid');
$cntno=$this->input->post('contactno');
$dob=$this->input->post('dob');
$pincode=$this->input->post('pincode');
$this->load->model('Insert_Model');
$this->Insert_Model->insertdata($fname,$email,$cntno,$dob,$pincode);
$this->load->view('insert');
} else {
$this->load->view('insert');
}
}

// For data updation
public function updatedetails(){
$this->form_validation->set_rules('firstname','First Name','required|alpha');		
$this->form_validation->set_rules('emailid','Email id','required|valid_email');
$this->form_validation->set_rules('contactno','Contact Number','required|numeric|exact_length[10]');
$this->form_validation->set_rules('dob','Date Of Birth','required');	
$this->form_validation->set_rules('pincode','Pincode','required');		

if($this->form_validation->run()){
$fname=$this->input->post('firstname');
$email=$this->input->post('emailid');
$cntno=$this->input->post('contactno');
$dob=$this->input->post('dob');
$pincode=$this->input->post('pincode');
$usid=$this->input->post('userid');
$this->load->model('Insert_Model');
$this->Insert_Model->updatedetails($fname,$email,$cntno,$dob,$pincode,$usid);
} else {
$this->session->set_flashdata('error', 'Somthing went worng. Try again with valid details !!');
		redirect('read');
}
}

}